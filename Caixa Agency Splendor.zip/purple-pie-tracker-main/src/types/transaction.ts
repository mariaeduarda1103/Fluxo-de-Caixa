
export interface Transaction {
  id: number;
  type: 'entrada' | 'saida';
  description: string;
  amount: number;
  date: string;
  seller?: string;
  payer?: string;
}
