
import { useState, useEffect } from "react";
import { Transaction } from "@/types/transaction";
import { toast } from "sonner";

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (transaction: Transaction) => void;
  editingTransaction?: Transaction;
}

const TransactionModal = ({
  isOpen,
  onClose,
  onSubmit,
  editingTransaction
}: TransactionModalProps) => {
  const [transaction, setTransaction] = useState<Partial<Transaction>>({
    type: 'entrada',
    description: '',
    amount: 0,
    date: new Date().toISOString().split('T')[0],
    seller: '',
    payer: ''
  });

  useEffect(() => {
    if (editingTransaction) {
      setTransaction(editingTransaction);
    }
  }, [editingTransaction]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!transaction.description || !transaction.amount) {
      toast.error("Por favor, preencha todos os campos obrigatórios.");
      return;
    }

    onSubmit({
      id: editingTransaction?.id || Date.now(),
      type: transaction.type as 'entrada' | 'saida',
      description: transaction.description as string,
      amount: Number(transaction.amount),
      date: transaction.date as string,
      seller: transaction.seller,
      payer: transaction.payer
    });

    setTransaction({
      type: 'entrada',
      description: '',
      amount: 0,
      date: new Date().toISOString().split('T')[0],
      seller: '',
      payer: ''
    });
    onClose();
  };

  if (!isOpen) return null;

  const vendedores = ["Italo Rafael", "Maria Eduarda", "Outro"];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-full max-w-md">
        <h3 className="text-lg font-semibold mb-4">
          {editingTransaction ? 'Editar Transação' : 'Nova Transação'}
        </h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tipo
            </label>
            <select
              value={transaction.type}
              onChange={(e) => setTransaction({...transaction, type: e.target.value as 'entrada' | 'saida'})}
              className="w-full p-2 border rounded-md"
            >
              <option value="entrada">Entrada</option>
              <option value="saida">Saída</option>
            </select>
          </div>

          {transaction.type === 'entrada' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Vendedor
                </label>
                <select
                  value={transaction.seller || ''}
                  onChange={(e) => setTransaction({...transaction, seller: e.target.value})}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="">Selecione um vendedor</option>
                  {vendedores.map((vendedor) => (
                    <option key={vendedor} value={vendedor}>{vendedor}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Pagador
                </label>
                <input
                  type="text"
                  value={transaction.payer || ''}
                  onChange={(e) => setTransaction({...transaction, payer: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  placeholder="Nome de quem pagou"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Descrição
            </label>
            <input
              type="text"
              value={transaction.description}
              onChange={(e) => setTransaction({...transaction, description: e.target.value})}
              className="w-full p-2 border rounded-md"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Valor
            </label>
            <input
              type="number"
              value={transaction.amount}
              onChange={(e) => setTransaction({...transaction, amount: Number(e.target.value)})}
              className="w-full p-2 border rounded-md"
              required
              min="0"
              step="0.01"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Data
            </label>
            <input
              type="date"
              value={transaction.date}
              onChange={(e) => setTransaction({...transaction, date: e.target.value})}
              className="w-full p-2 border rounded-md"
              required
            />
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md"
            >
              {editingTransaction ? 'Salvar' : 'Adicionar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TransactionModal;
