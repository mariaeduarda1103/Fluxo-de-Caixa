
import { useState, useEffect } from 'react';
import { Upload } from 'lucide-react';

const LogoUpload = () => {
  const [logo, setLogo] = useState<string | null>(null);

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogo(reader.result as string);
        // Salvar no localStorage para persistir
        localStorage.setItem('companyLogo', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Carregar logo do localStorage ao montar o componente
  useEffect(() => {
    const savedLogo = localStorage.getItem('companyLogo');
    if (savedLogo) {
      setLogo(savedLogo);
    }
  }, []);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Logo da Empresa</h3>
      <div className="flex items-center gap-4">
        <div className="w-24 h-24 border-2 border-dashed rounded-lg flex items-center justify-center overflow-hidden">
          {logo ? (
            <img src={logo} alt="Logo da empresa" className="w-full h-full object-contain" />
          ) : (
            <Upload className="w-8 h-8 text-gray-400" />
          )}
        </div>
        <div>
          <label className="block">
            <span className="sr-only">Escolher logo</span>
            <input
              type="file"
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
              accept="image/*"
              onChange={handleLogoChange}
            />
          </label>
          <p className="mt-1 text-sm text-gray-500">PNG, JPG até 5MB</p>
        </div>
      </div>
    </div>
  );
};

export default LogoUpload;
