
import { Download } from 'lucide-react';
import { loadData } from '@/services/storage';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

interface ReportData {
  date: string;
  title: string;
  data: any;
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

const ReportExport = ({ data }: { data: ReportData }) => {
  const handleExport = () => {
    const storageData = loadData();
    const currentDate = new Date().toLocaleDateString('pt-BR');
    
    // Criar PDF
    const doc = new jsPDF();
    
    // Título
    doc.setFontSize(20);
    doc.text('Relatório Financeiro', 20, 20);
    
    // Data do relatório
    doc.setFontSize(12);
    doc.text(`Data: ${currentDate}`, 20, 30);

    // Resumo financeiro
    const receitas = storageData.transactions
      .filter(t => t.type === 'entrada')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const despesas = storageData.transactions
      .filter(t => t.type === 'saida')
      .reduce((sum, t) => sum + t.amount, 0);

    const resumoFinanceiro = [
      ['Receitas Totais', formatCurrency(receitas)],
      ['Despesas Totais', formatCurrency(despesas)],
      ['Lucro Líquido', formatCurrency(receitas - despesas)],
      ['Meta Mensal', formatCurrency(storageData.goals?.monthly || 0)],
      ['Realizado', formatCurrency(storageData.goals?.current || 0)],
    ];

    // @ts-ignore
    doc.autoTable({
      startY: 40,
      head: [['Descrição', 'Valor']],
      body: resumoFinanceiro,
      theme: 'grid',
      styles: { fontSize: 10, cellPadding: 5 },
      headStyles: { fillColor: [93, 63, 211] }
    });

    // Vendas por vendedor
    const vendasPorVendedor = storageData.transactions
      .filter(t => t.type === 'entrada')
      .reduce((acc, t) => {
        const seller = t.seller || 'Sem vendedor';
        acc[seller] = (acc[seller] || 0) + t.amount;
        return acc;
      }, {} as Record<string, number>);

    const vendasPorVendedorData = Object.entries(vendasPorVendedor).map(([seller, amount]) => [
      seller,
      formatCurrency(amount)
    ]);

    // @ts-ignore
    doc.autoTable({
      startY: (doc as any).lastAutoTable.finalY + 20,
      head: [['Vendedor', 'Total']],
      body: vendasPorVendedorData,
      theme: 'grid',
      styles: { fontSize: 10, cellPadding: 5 },
      headStyles: { fillColor: [93, 63, 211] }
    });

    // Lista de transações
    const transacoesData = storageData.transactions.map(t => [
      new Date(t.date).toLocaleDateString('pt-BR'),
      t.type === 'entrada' ? 'Entrada' : 'Saída',
      t.description,
      formatCurrency(t.amount),
      t.seller || 'N/A',
      t.payer || 'N/A'
    ]);

    // @ts-ignore
    doc.autoTable({
      startY: (doc as any).lastAutoTable.finalY + 20,
      head: [['Data', 'Tipo', 'Descrição', 'Valor', 'Vendedor', 'Pagador']],
      body: transacoesData,
      theme: 'grid',
      styles: { fontSize: 10, cellPadding: 5 },
      headStyles: { fillColor: [93, 63, 211] }
    });

    // Salvar o PDF
    doc.save(`relatorio-${currentDate.replace(/\//g, '-')}.pdf`);
  };

  return (
    <button
      onClick={handleExport}
      className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors"
    >
      <Download className="w-4 h-4" />
      Exportar PDF
    </button>
  );
};

export default ReportExport;
