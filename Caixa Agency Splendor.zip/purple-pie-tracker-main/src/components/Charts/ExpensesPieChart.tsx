
import { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Transaction } from '@/types/transaction';

interface ExpensesPieChartProps {
  transactions: Transaction[];
}

const COLORS = ['#5D3FD3', '#A17CFF', '#4B32A8', '#8B5CF6', '#C4B5FD'];

const ExpensesPieChart = ({ transactions }: ExpensesPieChartProps) => {
  // Agrupar transações por vendedor
  const sellerData = transactions.reduce((acc, transaction) => {
    const seller = transaction.seller || 'Sem vendedor';
    const existingSeller = acc.find(item => item.name === seller);
    if (existingSeller) {
      existingSeller.value += transaction.amount;
    } else {
      acc.push({ name: seller, value: transaction.amount });
    }
    return acc;
  }, [] as { name: string; value: number }[]);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm h-[400px] card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Distribuição por Vendedor</h3>
          <p className="text-sm text-gray-500">Visão geral das vendas por consultor</p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={sellerData}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={120}
            fill="#8884d8"
            dataKey="value"
          >
            {sellerData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value) => `R$ ${Number(value).toLocaleString()}`} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ExpensesPieChart;
