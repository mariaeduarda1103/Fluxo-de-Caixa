
import { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { loadData } from '@/services/storage';

const SalesBarChart = () => {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    updateChartData();
    window.addEventListener('storage', updateChartData);
    return () => window.removeEventListener('storage', updateChartData);
  }, []);

  const updateChartData = () => {
    const storageData = loadData();
    const transactions = storageData.transactions;
    
    // Criar um mapa de vendas por mês e vendedor
    const salesMap = new Map();
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    
    transactions.forEach(t => {
      if (t.type === 'entrada') {
        const date = new Date(t.date);
        const month = months[date.getMonth()];
        const seller = t.seller || 'Sem vendedor';
        
        if (!salesMap.has(month)) {
          salesMap.set(month, {});
        }
        
        const monthData = salesMap.get(month);
        monthData[seller] = (monthData[seller] || 0) + t.amount;
      }
    });
    
    // Converter o mapa em array para o gráfico
    const chartData = months.map(month => ({
      month,
      ...(salesMap.get(month) || {})
    }));
    
    setData(chartData);
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm h-[400px] card-hover">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Vendas por Mês</h3>
          <p className="text-sm text-gray-500">Desempenho mensal dos vendedores</p>
        </div>
      </div>
      
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis tickFormatter={(value) => `R$ ${value/1000}k`} />
          <Tooltip formatter={(value) => `R$ ${Number(value).toLocaleString()}`} />
          <Legend />
          {Object.keys(data[0] || {}).filter(key => key !== 'month').map((seller, index) => (
            <Bar 
              key={seller} 
              name={seller} 
              dataKey={seller} 
              fill={COLORS[index % COLORS.length]} 
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default SalesBarChart;

const COLORS = ['#5D3FD3', '#A17CFF', '#4B32A8', '#8B5CF6', '#C4B5FD'];
