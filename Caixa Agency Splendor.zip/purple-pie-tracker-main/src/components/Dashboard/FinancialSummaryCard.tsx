
import { useEffect, useState } from "react";
import { ArrowUpCircle, ArrowDownCircle, TrendingUp } from "lucide-react";
import { Transaction } from "@/types/transaction";

interface FinancialSummaryCardProps {
  transactions: Transaction[];
}

const FinancialSummaryCard = ({ transactions }: FinancialSummaryCardProps) => {
  const [financials, setFinancials] = useState({
    revenue: 0,
    expenses: 0,
    netProfit: 0,
    revenueChange: 0,
    expensesChange: 0,
    netProfitChangePercent: 0
  });

  useEffect(() => {
    const currentDate = new Date();
    const previousMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1);

    const currentMonthTransactions = transactions.filter(t => 
      new Date(t.date).getMonth() === currentDate.getMonth() &&
      new Date(t.date).getFullYear() === currentDate.getFullYear()
    );

    const previousMonthTransactions = transactions.filter(t => 
      new Date(t.date).getMonth() === previousMonth.getMonth() &&
      new Date(t.date).getFullYear() === previousMonth.getFullYear()
    );

    const totalRevenue = currentMonthTransactions
      .filter(t => t.type === 'entrada')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalExpenses = currentMonthTransactions
      .filter(t => t.type === 'saida')
      .reduce((sum, t) => sum + t.amount, 0);

    const previousRevenue = previousMonthTransactions
      .filter(t => t.type === 'entrada')
      .reduce((sum, t) => sum + t.amount, 0);

    const previousExpenses = previousMonthTransactions
      .filter(t => t.type === 'saida')
      .reduce((sum, t) => sum + t.amount, 0);

    const revenueChange = previousRevenue ? ((totalRevenue - previousRevenue) / previousRevenue) * 100 : 0;
    const expensesChange = previousExpenses ? ((totalExpenses - previousExpenses) / previousExpenses) * 100 : 0;
    const netProfitChange = (totalRevenue - totalExpenses) - (previousRevenue - previousExpenses);
    const netProfitChangePercent = (previousRevenue - previousExpenses) ? 
      (netProfitChange / (previousRevenue - previousExpenses)) * 100 : 0;

    setFinancials({
      revenue: totalRevenue,
      expenses: totalExpenses,
      netProfit: totalRevenue - totalExpenses,
      revenueChange,
      expensesChange,
      netProfitChangePercent
    });
  }, [transactions]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-slide-in">
      <div className="bg-white p-6 rounded-xl shadow-sm card-hover">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Receita Total</p>
            <h3 className="text-2xl font-bold text-gray-800 mt-1">
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
              }).format(financials.revenue)}
            </h3>
            <div className="flex items-center gap-1 mt-1">
              <span className={`text-sm ${financials.revenueChange >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {financials.revenueChange >= 0 ? '+' : ''}{financials.revenueChange.toFixed(1)}%
              </span>
              <span className="text-xs text-gray-500">vs. mês anterior</span>
            </div>
          </div>
          <div className="p-3 bg-green-100 rounded-full">
            <ArrowUpCircle className="w-6 h-6 text-green-500" />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm card-hover">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Despesas</p>
            <h3 className="text-2xl font-bold text-gray-800 mt-1">
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
              }).format(financials.expenses)}
            </h3>
            <div className="flex items-center gap-1 mt-1">
              <span className={`text-sm ${financials.expensesChange >= 0 ? 'text-red-500' : 'text-green-500'}`}>
                {financials.expensesChange >= 0 ? '+' : ''}{financials.expensesChange.toFixed(1)}%
              </span>
              <span className="text-xs text-gray-500">vs. mês anterior</span>
            </div>
          </div>
          <div className="p-3 bg-red-100 rounded-full">
            <ArrowDownCircle className="w-6 h-6 text-red-500" />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm card-hover">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Lucro Líquido</p>
            <h3 className="text-2xl font-bold text-gray-800 mt-1">
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
              }).format(financials.netProfit)}
            </h3>
            <div className="flex items-center gap-1 mt-1">
              <span className={`text-sm ${financials.netProfitChangePercent >= 0 ? 'text-primary' : 'text-red-500'}`}>
                {financials.netProfitChangePercent >= 0 ? '+' : ''}{financials.netProfitChangePercent.toFixed(1)}%
              </span>
              <span className="text-xs text-gray-500">vs. mês anterior</span>
            </div>
          </div>
          <div className="p-3 bg-primary/10 rounded-full">
            <TrendingUp className="w-6 h-6 text-primary" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialSummaryCard;
