
import { useState, useEffect } from "react";
import { Bird, Bell, Settings, User } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const DashboardHeader = () => {
  const location = useLocation();
  const [logoUrl, setLogoUrl] = useState<string | null>(null);

  // Carregar logo do localStorage
  useEffect(() => {
    const savedLogo = localStorage.getItem('companyLogo');
    if (savedLogo) {
      setLogoUrl(savedLogo);
    }
  }, []);

  return (
    <header className="w-full bg-white p-6 rounded-xl shadow-sm animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-3">
            <div className="p-3 bg-primary/10 rounded-xl">
              {logoUrl ? (
                <img src={logoUrl} alt="Logo" className="w-6 h-6 object-contain" />
              ) : (
                <Bird className="w-6 h-6 text-primary" />
              )}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Agency Splendor</h1>
              <p className="text-sm text-gray-500">Gestão Financeira</p>
            </div>
          </Link>
        </div>
        <div className="flex items-center gap-6">
          <nav className="hidden md:flex items-center gap-4">
            <Link 
              to="/"
              className={`px-4 py-2 text-sm font-medium ${
                location.pathname === '/' 
                  ? 'text-primary' 
                  : 'text-gray-600 hover:text-gray-900'
              } transition-colors`}
            >
              Visão Geral
            </Link>
            <Link 
              to="/transactions"
              className={`px-4 py-2 text-sm font-medium ${
                location.pathname === '/transactions' 
                  ? 'text-primary' 
                  : 'text-gray-600 hover:text-gray-900'
              } transition-colors`}
            >
              Transações
            </Link>
            <Link 
              to="/reports"
              className={`px-4 py-2 text-sm font-medium ${
                location.pathname === '/reports' 
                  ? 'text-primary' 
                  : 'text-gray-600 hover:text-gray-900'
              } transition-colors`}
            >
              Relatórios
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-600 hover:text-primary transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <Link 
              to="/settings"
              className={`p-2 text-gray-600 hover:text-primary transition-colors ${
                location.pathname === '/settings' ? 'text-primary' : ''
              }`}
            >
              <Settings className="w-5 h-5" />
            </Link>
            <button className="p-2 text-gray-600 hover:text-primary transition-colors">
              <User className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default DashboardHeader;
