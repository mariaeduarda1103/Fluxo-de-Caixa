
import { Target, TrendingUp, Edit2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { loadData, saveData } from '@/services/storage';

const MonthlyGoalsCard = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [monthlyGoal, setMonthlyGoal] = useState(() => {
    const data = loadData();
    return data.goals?.monthly || 150000;
  });
  const [currentSales, setCurrentSales] = useState(() => {
    const data = loadData();
    return data.goals?.current || 0;
  });

  useEffect(() => {
    // Atualizar vendas atuais baseado nas transações
    const data = loadData();
    const currentMonth = new Date().getMonth();
    const monthSales = data.transactions
      .filter(t => t.type === 'entrada' && new Date(t.date).getMonth() === currentMonth)
      .reduce((sum, t) => sum + t.amount, 0);
    setCurrentSales(monthSales);
  }, []);

  const percentageAchieved = (currentSales / monthlyGoal) * 100;
  const remainingDays = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate() - new Date().getDate();

  const handleSave = () => {
    saveData({
      goals: {
        monthly: monthlyGoal,
        current: currentSales
      }
    });
    setIsEditing(false);
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm card-hover">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">Meta Mensal</h3>
          <p className="text-sm text-gray-500">Vendas de Sites e Serviços</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setIsEditing(true)}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <Edit2 className="w-4 h-4 text-gray-600" />
          </button>
          <div className="p-3 bg-primary/10 rounded-full">
            <Target className="w-6 h-6 text-primary" />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Progresso</span>
            <span className="text-sm font-medium text-primary">{percentageAchieved.toFixed(1)}%</span>
          </div>
          <div className="h-2 bg-gray-100 rounded-full">
            <div 
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${percentageAchieved}%` }}
            ></div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-500 mb-1">Meta</p>
            {isEditing ? (
              <input
                type="number"
                value={monthlyGoal}
                onChange={(e) => setMonthlyGoal(Number(e.target.value))}
                className="w-full p-2 border rounded-md text-sm"
              />
            ) : (
              <p className="text-lg font-semibold text-gray-800">
                R$ {monthlyGoal.toLocaleString()}
              </p>
            )}
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-500 mb-1">Realizado</p>
            <p className="text-lg font-semibold text-gray-800">
              R$ {currentSales.toLocaleString()}
            </p>
          </div>
        </div>

        {isEditing && (
          <div className="flex justify-end gap-2">
            <button
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800"
            >
              Cancelar
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md"
            >
              Salvar
            </button>
          </div>
        )}

        <div className="border-t pt-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-800">Faltam {remainingDays} dias</p>
              <p className="text-xs text-gray-500">para atingir a meta</p>
            </div>
            <div className="flex items-center text-green-500">
              <TrendingUp className="w-4 h-4 mr-1" />
              <span className="text-sm font-medium">No caminho</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonthlyGoalsCard;
