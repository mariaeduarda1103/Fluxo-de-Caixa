
import { Transaction } from "@/types/transaction";

interface StorageData {
  transactions: Transaction[];
  goals: {
    monthly: number;
    current: number;
  };
  settings: {
    companyName: string;
    logo?: string;
  };
}

const STORAGE_KEY = 'agency_splendor_data';

const defaultData: StorageData = {
  transactions: [],
  goals: {
    monthly: 150000,
    current: 115000,
  },
  settings: {
    companyName: 'Agency Splendor',
  },
};

export const loadData = (): StorageData => {
  const savedData = localStorage.getItem(STORAGE_KEY);
  if (savedData) {
    return JSON.parse(savedData);
  }
  return defaultData;
};

export const saveData = (data: Partial<StorageData>) => {
  const currentData = loadData();
  const newData = {
    ...currentData,
    ...data,
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
  return newData;
};

export const updateTransactions = (transactions: Transaction[]) => {
  return saveData({ transactions });
};

export const updateGoals = (goals: { monthly: number; current: number }) => {
  return saveData({ goals });
};

export const updateSettings = (settings: { companyName: string; logo?: string }) => {
  return saveData({ settings });
};
