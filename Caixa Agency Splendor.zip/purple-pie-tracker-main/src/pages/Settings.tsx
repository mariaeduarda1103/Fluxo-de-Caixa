
import DashboardHeader from "@/components/Dashboard/DashboardHeader";
import LogoUpload from "@/components/Settings/LogoUpload";

const Settings = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto py-8 px-4 space-y-6">
        <DashboardHeader />
        <div className="grid gap-6">
          <LogoUpload />
          {/* Adicionar mais seções de configurações aqui */}
        </div>
      </div>
    </div>
  );
};

export default Settings;
