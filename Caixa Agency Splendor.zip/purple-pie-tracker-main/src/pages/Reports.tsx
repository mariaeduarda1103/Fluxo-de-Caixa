
import { useState } from "react";
import DashboardHeader from "@/components/Dashboard/DashboardHeader";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from 'recharts';
import { Download } from "lucide-react";

const salesData = [
  { month: 'Jan', receitas: 45000, despesas: 32000 },
  { month: 'Fev', receitas: 52000, despesas: 35000 },
  { month: 'Mar', receitas: 48000, despesas: 31000 },
  { month: 'Abr', receitas: 61000, despesas: 42000 },
  { month: 'Mai', receitas: 55000, despesas: 38000 },
  { month: 'Jun', receitas: 67000, despesas: 45000 },
];

const categoryData = [
  { name: 'Sites', value: 45000 },
  { name: 'Manutenção', value: 25000 },
  { name: 'Consultoria', value: 18000 },
  { name: 'Marketing', value: 12000 },
];

const COLORS = ['#5D3FD3', '#A17CFF', '#4B32A8', '#8B5CF6'];

const Reports = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto py-8 px-4 space-y-6">
        <DashboardHeader />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Resumo Financeiro */}
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Resumo Financeiro</h3>
                <p className="text-sm text-gray-500">Visão geral do período</p>
              </div>
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="p-2 border rounded-md text-sm"
              >
                <option value="month">Último Mês</option>
                <option value="quarter">Último Trimestre</option>
                <option value="year">Último Ano</option>
              </select>
            </div>
            <div className="space-y-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Receitas Totais</p>
                <p className="text-2xl font-bold text-gray-800">R$ 328.000</p>
                <p className="text-sm text-green-600">+15% vs período anterior</p>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Despesas Totais</p>
                <p className="text-2xl font-bold text-gray-800">R$ 223.000</p>
                <p className="text-sm text-red-600">+8% vs período anterior</p>
              </div>
              <div className="bg-primary/10 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Lucro Líquido</p>
                <p className="text-2xl font-bold text-gray-800">R$ 105.000</p>
                <p className="text-sm text-primary">+22% vs período anterior</p>
              </div>
            </div>
          </div>

          {/* Gráfico de Categorias */}
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Vendas por Categoria</h3>
                <p className="text-sm text-gray-500">Distribuição de receitas</p>
              </div>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <Download className="w-4 h-4 text-gray-600" />
              </button>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `R$ ${value.toLocaleString()}`} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Gráfico de Receitas x Despesas */}
          <div className="bg-white p-6 rounded-xl shadow-sm md:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Receitas x Despesas</h3>
                <p className="text-sm text-gray-500">Comparativo mensal</p>
              </div>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <Download className="w-4 h-4 text-gray-600" />
              </button>
            </div>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={salesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis tickFormatter={(value) => `R$ ${value/1000}k`} />
                  <Tooltip formatter={(value) => `R$ ${value.toLocaleString()}`} />
                  <Legend />
                  <Bar name="Receitas" dataKey="receitas" fill="#5D3FD3" />
                  <Bar name="Despesas" dataKey="despesas" fill="#A17CFF" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
