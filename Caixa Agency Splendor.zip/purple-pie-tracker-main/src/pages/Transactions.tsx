import { useState, useEffect } from "react";
import { ArrowUpRight, Calendar, Plus, Search, Trash2, Edit2 } from "lucide-react";
import DashboardHeader from "@/components/Dashboard/DashboardHeader";
import { Transaction } from "@/types/transaction";
import { loadData, updateTransactions } from "@/services/storage";
import { toast } from "sonner";

const Transactions = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [newTransaction, setNewTransaction] = useState<Partial<Transaction>>({
    type: 'entrada',
    description: '',
    amount: 0,
    date: new Date().toISOString().split('T')[0],
    seller: ''
  });
  const vendedores = ["Italo Rafael", "Maria Eduarda", "Outro"];

  useEffect(() => {
    const data = loadData();
    setTransactions(data.transactions);

    const handleStorageChange = () => {
      const updatedData = loadData();
      setTransactions(updatedData.transactions);
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const handleAddTransaction = () => {
    if (newTransaction.description && newTransaction.amount) {
      const updatedTransactions = [
        {
          id: Math.max(...transactions.map(t => t.id), 0) + 1,
          type: newTransaction.type as 'entrada' | 'saida',
          description: newTransaction.description,
          amount: newTransaction.amount,
          date: newTransaction.date || new Date().toISOString().split('T')[0],
          seller: newTransaction.seller || ''
        },
        ...transactions
      ];
      
      setTransactions(updatedTransactions);
      updateTransactions(updatedTransactions);
      setIsAdding(false);
      setNewTransaction({
        type: 'entrada',
        description: '',
        amount: 0,
        date: new Date().toISOString().split('T')[0],
        seller: ''
      });
      toast.success('Transação adicionada com sucesso!');
    }
  };

  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setNewTransaction(transaction);
    setIsAdding(true);
  };

  const handleUpdateTransaction = () => {
    if (editingTransaction && newTransaction.description && newTransaction.amount) {
      const updatedTransactions = transactions.map(t => 
        t.id === editingTransaction.id 
          ? {
              ...t,
              type: newTransaction.type as 'entrada' | 'saida',
              description: newTransaction.description,
              amount: newTransaction.amount,
              date: newTransaction.date || t.date,
              seller: newTransaction.seller || ''
            }
          : t
      );
      
      setTransactions(updatedTransactions);
      updateTransactions(updatedTransactions);
      setIsAdding(false);
      setEditingTransaction(null);
      setNewTransaction({
        type: 'entrada',
        description: '',
        amount: 0,
        date: new Date().toISOString().split('T')[0],
        seller: ''
      });
      toast.success('Transação atualizada com sucesso!');
    }
  };

  const handleDeleteTransaction = (id: number) => {
    const updatedTransactions = transactions.filter(t => t.id !== id);
    setTransactions(updatedTransactions);
    updateTransactions(updatedTransactions);
    toast.success('Transação excluída com sucesso!');
  };

  const filteredTransactions = transactions.filter(transaction =>
    transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (transaction.seller || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto py-8 px-4 space-y-6">
        <DashboardHeader />
        
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Transações</h2>
              <p className="text-sm text-gray-500">Gerencie suas entradas e saídas</p>
            </div>
            <div className="flex gap-4">
              <div className="relative">
                <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Buscar transação..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-white/50"
                />
              </div>
              <button
                onClick={() => {
                  setEditingTransaction(null);
                  setNewTransaction({
                    type: 'entrada',
                    description: '',
                    amount: 0,
                    date: new Date().toISOString().split('T')[0],
                    seller: ''
                  });
                  setIsAdding(true);
                }}
                className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors"
              >
                <Plus className="w-4 h-4" />
                Nova Transação
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {filteredTransactions.map((transaction) => (
              <div key={transaction.id} className="border-b border-gray-100 pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-start gap-3">
                    <div className={`p-2 ${transaction.type === 'entrada' ? 'bg-green-100' : 'bg-red-100'} rounded-lg`}>
                      <ArrowUpRight 
                        className={`w-4 h-4 ${transaction.type === 'entrada' ? 'text-green-500' : 'text-red-500 rotate-180'}`} 
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-800">{transaction.description}</p>
                      <p className="text-xs text-gray-500">Vendedor: {transaction.seller || 'N/A'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className={`text-sm font-medium ${transaction.type === 'entrada' ? 'text-green-500' : 'text-red-500'}`}>
                        {transaction.type === 'entrada' ? '+' : '-'} R$ {transaction.amount.toLocaleString()}
                      </p>
                      <div className="flex items-center gap-1 mt-1">
                        <Calendar className="w-3 h-3 text-gray-400" />
                        <p className="text-xs text-gray-500">
                          {new Date(transaction.date).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleEditTransaction(transaction)}
                        className="p-1 hover:bg-gray-100 rounded-full transition-colors"
                      >
                        <Edit2 className="w-4 h-4 text-gray-600" />
                      </button>
                      <button
                        onClick={() => handleDeleteTransaction(transaction.id)}
                        className="p-1 hover:bg-gray-100 rounded-full transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal de Transação */}
      {isAdding && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-md shadow-xl">
            <h3 className="text-lg font-semibold mb-4">
              {editingTransaction ? 'Editar Transação' : 'Nova Transação'}
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tipo
                </label>
                <select
                  value={newTransaction.type}
                  onChange={(e) => setNewTransaction({...newTransaction, type: e.target.value as 'entrada' | 'saida'})}
                  className="w-full p-2 border rounded-md bg-white"
                >
                  <option value="entrada">Entrada</option>
                  <option value="saida">Saída</option>
                </select>
              </div>

              {newTransaction.type === 'entrada' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Vendedor
                    </label>
                    <select
                      value={newTransaction.seller || ''}
                      onChange={(e) => setNewTransaction({...newTransaction, seller: e.target.value})}
                      className="w-full p-2 border rounded-md"
                    >
                      <option value="">Selecione um vendedor</option>
                      {vendedores.map((vendedor) => (
                        <option key={vendedor} value={vendedor}>{vendedor}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Pagador
                    </label>
                    <input
                      type="text"
                      value={newTransaction.payer || ''}
                      onChange={(e) => setNewTransaction({...newTransaction, payer: e.target.value})}
                      className="w-full p-2 border rounded-md"
                      placeholder="Nome de quem pagou"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Descrição
                </label>
                <input
                  type="text"
                  value={newTransaction.description}
                  onChange={(e) => setNewTransaction({...newTransaction, description: e.target.value})}
                  className="w-full p-2 border rounded-md"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Valor
                </label>
                <input
                  type="number"
                  value={newTransaction.amount}
                  onChange={(e) => setNewTransaction({...newTransaction, amount: Number(e.target.value)})}
                  className="w-full p-2 border rounded-md"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data
                </label>
                <input
                  type="date"
                  value={newTransaction.date}
                  onChange={(e) => setNewTransaction({...newTransaction, date: e.target.value})}
                  className="w-full p-2 border rounded-md"
                />
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <button
                  onClick={() => {
                    setIsAdding(false);
                    setEditingTransaction(null);
                    setNewTransaction({
                      type: 'entrada',
                      description: '',
                      amount: 0,
                      date: new Date().toISOString().split('T')[0],
                      seller: '',
                      payer: ''
                    });
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800"
                >
                  Cancelar
                </button>
                <button
                  onClick={editingTransaction ? handleUpdateTransaction : handleAddTransaction}
                  className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md"
                >
                  {editingTransaction ? 'Salvar' : 'Adicionar'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Transactions;
