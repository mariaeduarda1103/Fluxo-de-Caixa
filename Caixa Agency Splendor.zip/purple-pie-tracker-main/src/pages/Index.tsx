
import { useState, useEffect } from "react";
import DashboardHeader from "@/components/Dashboard/DashboardHeader";
import FinancialSummaryCard from "@/components/Dashboard/FinancialSummaryCard";
import MonthlyGoalsCard from "@/components/Dashboard/MonthlyGoalsCard";
import SalesBarChart from "@/components/Charts/SalesBarChart";
import ExpensesPieChart from "@/components/Charts/ExpensesPieChart";
import { loadData } from "@/services/storage";
import { Transaction } from "@/types/transaction";
import ReportExport from "@/components/Reports/ReportExport";

const Index = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  useEffect(() => {
    const data = loadData();
    setTransactions(data.transactions || []);

    // Atualizar quando houver mudanças no localStorage
    const handleStorageChange = () => {
      const updatedData = loadData();
      setTransactions(updatedData.transactions || []);
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto py-8 px-4 space-y-6">
        <div className="flex justify-between items-center">
          <DashboardHeader />
          <ReportExport data={{ date: new Date().toISOString(), title: "Relatório Financeiro", data: transactions }} />
        </div>
        
        <FinancialSummaryCard transactions={transactions} />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <MonthlyGoalsCard />
          <ExpensesPieChart transactions={transactions.filter(t => t.type === 'entrada')} />
          <div className="md:col-span-2">
            <SalesBarChart />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
